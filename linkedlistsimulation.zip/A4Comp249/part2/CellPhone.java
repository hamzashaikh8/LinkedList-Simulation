//----------------------------------------
//Assignment 4

//Question: 2
//Written by: Maryan Khalil 40129572
//            
//----------------------------------------

/**
 * @author Maryan Khalil
 * @author Hamza Sheikh 40129291
 * COMP 249
 * Assignment #4
 * Due Date  19/04/2020
 */

import java.util.Scanner;

public class CellPhone implements Cloneable{

	// Declaration of Variables
	private long serialNum;
	private String brand;
	private int year;
	private double price;
    Scanner userinput = new Scanner(System.in);
	
	
	/**
	 * Default constructor
	 */
	public CellPhone() {
		serialNum = 0;
		brand = null;
		year = 0;
		price = 0;
	}

	/**
	 * Parameterized Constructor
	 * 
	 * @param serialNum corresponds to serial number
	 * @param brand correponds to brand
	 * @param price corresponds to price
	 * @param year corresponds to year 
	 */
	public CellPhone(long serialNum, String brand, double price, int year) {
		this.serialNum = serialNum;
		this.brand = brand;
		this.year = year;
		this.price = price;
	}
     

	/**
	 * Accessor method
	 * @return the serial number corresponds to serial number
	 */
	public long getSerialNum() {
		return serialNum;
	}
    
	/**
	 * Mutator method
	 * @param serialNum corresponds to serial number
	 */
	public void setSerialNum(long serialNum) {
		this.serialNum = serialNum;
	}
    
	/**
	 * Accessor method
	 * @return Brand corresponds to brand
	 */
	public String getBrand() {
		return brand;
	}
    /**
     * Mutator method  
     * @param brand corresponds to brand
     */
	public void setBrand(String brand) {
		this.brand = brand;
	}
    
	/**
	 * Accessor method
	 * @return year corresponds to year
	 */
	public int getYear() {
		return year;
	}
    
	/**
	 * Mutator method
	 * @param year corresponds to year
	 */
	public void setYear(int year) {
		this.year = year;
	}

	/**
	 * Accessor method
	 * @return the price corresponds to price
	 */
	public double getPrice() {
		return price;
	}
    /**
     * Mutator method
     * @param price corresponds to price
     */
	public void setPrice(double price) {
		this.price = price;
	}
    //toString method
	public String toString() {
		return serialNum + ": " + brand + " " + price + "$  " + year;
	}
	
	/**
	 * Copy Constructor which takes two parameters, the newly created object will be assigned the passed object values with the new serial number.
	 * @param cellPhone correponds to a cellphone object
	 * @param num  corresponds to a serial number
	 */
	public CellPhone(CellPhone cellPhone, long num) {
		this.brand = cellPhone.brand;
		this.year = cellPhone.year;
		this.price = cellPhone.price;
		this.serialNum = num;
	}
    
	/**
     * Equals method that compared all object attributes except serial num since it is unique to each object 
     */
	public boolean equals(Object obj) {
		if (this == null || obj == null || this.getClass() != obj.getClass())
			return false;
		else {
			CellPhone newOne = (CellPhone) obj;
			return (this.brand.equals(newOne.brand) && this.price == newOne.price && this.year == newOne.year);
		}

	}
	
    /**
     * Clone method which first checks if user entered an already exsiting serial num, if yes clone is called until user enters unique serial number 
     */
	public Object clone() throws CloneNotSupportedException 
	{
		System.out.println("Please enter the new serial number of phone object to be cloned: ");
		//System.out.println();
		long serialNumber = userinput.nextLong();
		CellPhone CellPhoneClone = new CellPhone((CellPhone)super.clone(),serialNumber);
		
		return CellPhoneClone;
	}

}//End of class
