//----------------------------------------
//Assignment 4

//Question: 2
//Written by: Maryan Khalil 40129572
//            Hamza Shaikh 40129291
//----------------------------------------

/**
 * @author Maryan Khalil 40129572
 * @author Hamza Shaikh 40129291
 * COMP 249
 * Assignment #4
 * Due Date  19/04/2020
 */

import java.util.NoSuchElementException;

public class CellList {

	/**
	 * Inner Class CellNode inner class creates a node for the to be added to the
	 * linked list from a CellPone object and a link implements cloneable interface
	 * in order to clone node
	 */

	private class CellNode implements Cloneable {

		private CellPhone phone;
		private CellNode link;

		// Default Constructor that sets both values to null
		public CellNode() {
			phone = null;
			link = null;
		}

		/**
		 * Parametalized constructor
		 * 
		 * @param a stands for the cellphone object determines by user
		 * @param b stands for pointer to cellNode Object determined by user
		 */
		public CellNode(CellPhone a, CellNode b) {
			this.phone = a;
			this.link = b;
		}

		/**
		 * Copy Constructor
		 * 
		 * @param x cellnode to be copied
		 */
		public CellNode(CellNode x) {
			this.phone = x.phone;
			this.link = x.link;
		}

		/**
		 * 
		 * Accessors and Mutators
		 */

		public CellPhone getPhone() {
			return phone;
		}

		/**
		 * This is a potential privacy leak as this variable is mutable and can therefore be changed for the object
		 * after having been initially created. This destroys the purpose of having a "private" CellPhone attribute. This can be fixed
		 * if CellPhone was defined as an inner class
		 * @param phone parameter sets Cellphone as determined by the user
		 */
		public void setPhone(CellPhone phone) {
			this.phone = phone;
		}

		public CellNode getLink() {
			return link;
		}

		/**
		 * This is a potential privacy leak as this variable is mutable and can
		 * therefore be changed for the object after having initially been created
		 * 
		 * @param link set link as determined by user
		 */
		public void setLink(CellNode link) {
			this.link = link;
		}

		// clone method
		/**
		 * clones CellNode object then returns it
		 * 
		 * @return returns cloned phones
		 */
		public Object clone() throws CloneNotSupportedException {
			CellNode CellNodeClone = (CellNode) super.clone();
			return CellNodeClone;
		}

		/**
		 * ToString method
		 */
		public String toString() {
			return phone.toString();
		}

	}// end of inner class

	/**
	 * start of CellList class head is the head of any given CellList size
	 * representes the size of a CellList Counter is a variable to keep track of the
	 * number of iterations in the different methods
	 */
	private CellNode head;
	private int size;
	private int counter;

	/**
	 * default constructor
	 */
	public CellList() {
		head = null;
		size = 0;
	}

	/*
	 * public CellList(CellList anotherOne) { size=anotherOne.size;//size is same as
	 * the passed object if (anotherOne.head==null)//special case:the passed list is
	 * empty { head=null; } else { head=null; CellNode t1=anotherOne.head,t2=null;
	 * while (t1!=null) { if(head==null) { head=new CellNode(t1);//using copy
	 * constructor to create a deep copy of the CellPhone object t2=head; } else {
	 * t2.link=new CellNode(t1);//using copy constructor to create a deep copy of
	 * the CellPhone object t2=t2.link; } t1=t1.link; } t2=null; } }
	 */

	/**
	 * copy constructor copies head of a list, allowing us to traverse through its
	 * list (only head required to copy entire list)
	 * 
	 * @param copy denotes the CellList Object taken as a parameter
	 */
	public CellList(CellList copy) {
		head = copy.head;

	}

	/**
	 * adds a CellPhone object to start of linked list by pointing head towards it
	 * 
	 * @param c denotes CellPhone object taken as a parameter
	 */
	public void addToStart(CellPhone c) {

		head = new CellNode(c, head);
		size++;
	}

	/**
	 * Adds CellPhone object at any given index
	 * 
	 * @param i     denotes CellPhone object taken as a parameter
	 * @param index denotes index, which is where the user would want the CellPhone
	 *              placed
	 */
	public void insertAtIndex(CellPhone i, int index) {
		if (index < 0 || index > (size - 1)) {
			throw new NoSuchElementException();
		} else if (head == null || index == 0) {
			head = new CellNode(i, head);
			size++;
		} else {
			int counter = 0;
			CellNode temp;
			temp = head;
			while (temp.link != null && counter < size) {

				if (counter == index - 1) {
					break;
				}

				temp = temp.link;

				counter++;
			}
			CellNode temp2;
			temp2 = temp.link;
			CellNode noder = new CellNode(i, temp.link);
			noder.link = temp2;
			temp.link = noder;

			size++;
		}
	}

	/**
	 * deletes CellNode as given index
	 * 
	 * @param index represents point at which CellNode should be deleted
	 */
	public void deleteFromIndex(int index) {
		if (index < 0 || index > (size - 1)) {
			throw new NoSuchElementException();
		} else {

			CellNode temp;
			temp = head;
			counter = 0;
			while (temp.link != null && counter < size) {

				if (counter == index - 1) {
					break;
				}

				temp = temp.link;

				counter++;
			}

			CellNode temp2;
			temp2 = temp.link;
			temp.link = temp2.link;

			size--;
		}
	}

	/**
	 * deletes CellNode from start of CellList
	 */
	public void deleteFromStart() {
		head = head.link;
		size--;
	}

	/**
	 * Replaces CellNode at any given index by another CellNode containing a
	 * CellPhone object, passed as a parameter
	 * 
	 * @param i     represents the CellPhone object to be inserted in the list
	 * @param index index a which the replacing should take place
	 */
	public void replaceAtIndex(CellPhone i, int index) {

		if (index < 0 || index > (size - 1)) {
			throw new NoSuchElementException();
		} else if (index == 0) {
			head = head.link;
			head = new CellNode(i, head);
		}

		else {

			CellNode position;
			position = head;
			counter = 0;
			while (position.link != null && counter < size) {

				if (counter == index - 1) {
					break;
				}

				position = position.link;

				counter++;
			}
			// deleting node
			CellNode temp;
			temp = position.link;
			position.link = temp.link;
			// creating node
			CellNode noder = new CellNode(i, position.link);

			// adding node
			noder.link = position.link;
			position.link = noder;

		}

	}

	/**
	 * finds CellPhone object by checking linked list for corresponding serial
	 * numbers, then returns object
	 * 
	 * @param l represents serial number wanting to be found
	 * @return returns CellPhone object with corresponding serial number
	 */
	public CellNode find(long l) {
		CellNode position = head;
		CellNode nuller = new CellNode();
		long foundSerial;
		counter = 1;
		while (position != null) {
			foundSerial = position.phone.getSerialNum();
			if (foundSerial == l) {

				return position;
			} else {
				counter++;
				position = position.link;
			}
		}
		return nuller;
	}

	/**
	 * checks to see if list contains CellPhone object with corresponding serial
	 * number and returns true if this is so, else it returns false
	 * 
	 * @param l represents serial number wanting to be found
	 * @return returns true if serial number is found in list, false if it is not
	 */
	public boolean contains(long l) {
		CellNode position = head;
		long foundSerial;
		while (position != null) {
			foundSerial = position.phone.getSerialNum();
			if (foundSerial == l) {
				return true;
			}
			position = position.link;

		}
		return false;
	}

	/**
	 * Checks to see if 2 linked list contain similar objects
	 * 
	 * @param c represents other linked list that is to be compared to
	 * @return returns true is both linked lists contain similar objects, false
	 *         otherwise
	 */
	public boolean equals(CellList c) {
		if (size != c.size) {
			return false;
		} else if (head == null && c.head != null || head != null && c.head == null) {
			return false;
		} else if (head == null && c.head == null) {
			return true;
		} else {
			counter = 0;
			int superCounter = 0;
			CellNode position;
			CellNode otherPosition;
			position = head;
			otherPosition = c.head;
			while (position.link != null && counter < size) {
				if (position.phone.equals(otherPosition.phone) == false) {
					while (otherPosition.link != null && superCounter < size) {

						if (otherPosition.equals(position)) {
							break;
						} else if (counter == size - 1 && otherPosition.equals(position) == false) {
							return false;
						}
						otherPosition = otherPosition.link;
						superCounter++;

					}
				}
				position = position.link;

				counter++;
			}
			return true;
		}

	}

	/**
	 * shows contents of linked list in organized manner as specified in assignment
	 * 
	 * @return returns contents of linked list in organized manner as specified in
	 *         assignment
	 */
	public String showContents() {
		String printList = "";
		CellNode position = head;
		counter = 1;
		while (position != null) {

			printList += "[" + position.phone + "]";
			if (position.link != null) {
				printList += " ---> ";
			} else {
				printList += " ---> X";
			}
			if (counter % 3 == 0 && counter != 0) {
				printList += "\n";
			}
			position = position.link;
			counter++;

		}
		return "The current size of the list is " + size
				+ ". Here are the contents of the list\n========================================================================\n"
				+ printList;
	}

	/**
	 * compares CellPhone to objects in linked list, making sure that no 2 CellPhone
	 * are identical or have the same serial number
	 * @param c denotes CellPhone object to be selectively added
	 */
	public void selectiveAddToStart(CellPhone c)
	{ 
		CellNode position;
	    position=head; 
	    int m=0; 
	    if(head==null) { addToStart(c); } 
	    else {
		while(position!=null && m<size) 
		{ if(position.phone.equals(c) || position.phone.getSerialNum() ==c.getSerialNum()) { break; } else
					if(m==(size-1) && (position.phone.equals(c))==false &&  position.phone.getSerialNum() !=c.getSerialNum()) 
					{ addToStart(c); }
		position=position.link; m++; } 
		} 
	    
	}
				 
    
	
	/** 
	 * gets counter
	 * @return returns counter value
	 */
	public int getCounter() 
	{ 
		return counter;
	}
	
	
}// end of class

