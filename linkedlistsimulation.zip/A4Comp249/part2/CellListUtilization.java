//----------------------------------------
//Assignment 4


//Question: 1
//Written by: Maryan Khalil 40129572
//            Hamza Shaikh 40129291
//----------------------------------------

/**
 * @author Maryan Khalil 40129572
 * @author Hamza Shaikh 40129291
 * COMP 249
 * Assignment #4
 * Due Date  19/04/2020
 */

import java.util.InputMismatchException;

import java.util.Scanner;
import java.io.*;


public class CellListUtilization {

	public static void main(String[] args) throws CloneNotSupportedException {
		// TODO Auto-generated method stub

		/** 
		 * declaring variables nuller 1, and 2 are lists that are set equal to one another for testing purposes, nuller 3 is an empty list
		 */
		CellList nuller1=new CellList(); 
		CellList nuller2=new CellList(); 
		CellList nuller3= new CellList();
		/** 
		 * In the try block, we are trying to open and read a text file(provided in the assignment) and create objects of type CellPhone to add to our linked list
		 */
		try 
		{
			Scanner scanner1= new Scanner(new FileInputStream("Cell_Info.txt"));
			Scanner scanner2= new Scanner(new FileInputStream("Cell_Info.txt"));
			int i=0;
			int z=0; 
			
			/** 
			 * counts how many items are in the text file in order to make an array of that size 
			 */
			while(scanner2.hasNextLine()) 
			{ 
				scanner2.nextLine();
				z++;
			}
			CellPhone[] array=new CellPhone[z];
			//CellPhone[] array2=new CellPhone[z];
			/** 
			 * adding CellPhone objects to array
			 */
			while(scanner1.hasNextLine()) 
			{ 
				
				int serial; 
				String brand; 
				double price; 
				int year; 
				serial=scanner1.nextInt(); 
				brand=scanner1.next(); 
				price=scanner1.nextDouble(); 
				year=scanner1.nextInt();
				
				
				array[i]=new CellPhone(serial, brand, price, year);
				//array2[i]=new CellPhone(serial, brand, year, price);
				i++;
			} 
			/** 
			 * calling selectiveAddToStart method which compares a CellPhone object to the entire linked list, if there is no duplicate it will add it in.
			 */
			for(int n=0; n<array.length; n++) 
			{ 
				nuller1.selectiveAddToStart(array[n]);  
			} 
			
			
			
			for(int b=0; b<array.length; b++) 
			{ 
				nuller2.selectiveAddToStart(array[b]); 
			} 
			System.out.println(nuller1.showContents());
			
		}
		/** 
		 * catches if file is not found
		 */
		catch(FileNotFoundException e) 
		{ 
			System.out.println("File not found, sorry.");
		}
		
		/** 
		 * finding object based on serial number 3 times using find method
		 */
		for(int i=0;i<3;i++)
		{
			System.out.println();
			System.out.println(); 
			System.out.println(); 
			System.out.print("Please type in the serial number of an item you would like to find:"); 
	
			//repeat until they type in a long 
			Scanner scanner3= new Scanner(System.in);
			try {
				while(!scanner3.hasNextLong()) 
				{
				    scanner3.next(); 
				    System.out.println("Please enter a valid input");
				} 
				long serialToFind = scanner3.nextLong();
				
				//CellList.CellNode found=nuller1.find(serialToFind);
				//System.out.println(found.getItem());
				System.out.println(nuller1.find(serialToFind));
				System.out.println("this is the counter: "+nuller1.getCounter());
				System.out.println(); 
				System.out.println(); 
			} catch(NullPointerException e) {
				System.out.println("Sorry this serial number is not in the list, try again");
				
			}
		
		}
	
		/** 
		 * testing equals method 
		 */
		System.out.println(); 
		System.out.println("Comparing nuller 1 and nuller 2 (should be true)");
		System.out.println(nuller1.equals(nuller2)); 
		System.out.println("Comparing nuller 1 and nuller 3 (should be false)");
		System.out.println(nuller1.equals(nuller3)); 
		
		/** 
		 * testing delete from start method
		 */
		System.out.println(); 
		System.out.println("Deleting SonyEricsson from start"); 
		nuller1.deleteFromStart();
		System.out.println(nuller1.showContents()); 
		
		/** 
		 * testing insert at index method
		 */
		System.out.println(); 
		System.out.println("Adding SonyEricsson after Blackberry"); 
		CellPhone phony=new CellPhone(1119000, "SonyEricsson", 347.94, 2009);
		nuller1.insertAtIndex(phony, 1); 
		System.out.println(nuller1.showContents());
		
		/** 
		 * testing delete at index method
		 */
		System.out.println(); 
		System.out.println("Deleting Apple from 3rd place (2nd index, index starts from 0)"); 
		nuller1.deleteFromIndex(2); 
		System.out.println(nuller1.showContents());
		
		/** 
		 * testing replaceAtIndex method
		 */
		System.out.println(); 
		System.out.println("Replacing Blackberry (current 1st place) with Apple"); 
		CellPhone phony2=new CellPhone(5909887, "Apple", 726.99, 2019);
		nuller1.replaceAtIndex(phony2, 0);  
		System.out.println(nuller1.showContents());
		

		/** 
		 * testing clone method 
		 */
		System.out.println(); 
		System.out.println("Testing clone method"); 
		CellPhone phoner = new CellPhone(5909887, "Apple ", 726.99, 2019);
	
		System.out.println(phoner.clone());
	}

}
